package com.company;

public class Shirt {
    private String productType;
    private String shirtSize;
    private  Double shirtPrice;
    private  int numberOfItems;

    public int getNumberOfItems() {
        return numberOfItems;
    }

    public void setNumberOfItems(int numberOfItems) {
        this.numberOfItems = numberOfItems;
    }

    public Double getShirtPrice() {
        return shirtPrice;
    }

    public void setShirtPrice(Double shirtPrice) {
        this.shirtPrice = shirtPrice;
    }

    public String getProductType() {
        return productType;
    }

    public void setProductType(String productType) {
        this.productType = productType;
    }

    public String getShirtSize() {
        return shirtSize;
    }

    public void setShirtSize(String shirtSize) {
        this.shirtSize = shirtSize;
    }
}
