package com.company;

public class Pants {
    private String productType;
    private String pantsSize;
    private  Double pantsPrice;
    private int numberOfItems;

    public String getProductType() {
        return productType;
    }

    public void setProductType(String productType) {
        this.productType = productType;
    }

    public String getPantsSize() {
        return pantsSize;
    }

    public void setPantsSize(String pantsSize) {
        this.pantsSize = pantsSize;
    }

    public Double getPantsPrice() {
        return pantsPrice;
    }

    public void setPantsPrice(Double pantsPrice) {
        this.pantsPrice = pantsPrice;
    }

    public int getNumberOfItems() {
        return numberOfItems;
    }

    public void setNumberOfItems(int numberOfItems) {
        this.numberOfItems = numberOfItems;
    }
}
