package com.company;

import com.company.implem.PanstImplEx;
import com.company.implem.ShirtsImplEx;

import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        PanstImplEx panstImplEx = new PanstImplEx();
        ShirtsImplEx shirtsImplEx = new ShirtsImplEx();


        Scanner scanner = new Scanner(System.in);


        System.out.println("Hello what would you like to buy");
        String response = scanner.toString();

        System.out.println("How many items");
        int numberOfItems = scanner.nextInt();

        panstImplEx.setNumberOfItems(numberOfItems);
        panstImplEx.getProductType();

        shirtsImplEx.setProductType(response);
        shirtsImplEx.setNumberOfItems(numberOfItems);

        Double totalPrice = shirtsImplEx.getTotal() + panstImplEx.getTotal();
        System.out.println("your amount due is as follows: R" + totalPrice );
    }

}
