package com.company.implem;

import com.company.Pants;

public interface PantsImpl {
   void getPantsPrice (String productTYpe, String size);

    double getTotal();

}
