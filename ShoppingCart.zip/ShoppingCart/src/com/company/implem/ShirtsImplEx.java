package com.company.implem;

import com.company.Shirt;

public class ShirtsImplEx extends Shirt implements ShirtsImpl{

    @Override
    public void getShirtPrice(String productTYpe, String size) {
        double s = 10;
        double m = 20;
        double l = 30;
        if(getProductType() == "T-Shirt"){
            if(getShirtSize() == "s"){
                setShirtPrice(s);
            }
            else if(getShirtSize() == "m"){
                setShirtPrice(m);
            }
            else{
                setShirtPrice(l);
            }
        }
        else if (getProductType()  == "Golfer"){
            if(getShirtSize() == "s"){
                setShirtPrice(s * 2);
            }
            else if(getShirtSize() == "m"){
                setShirtPrice(m * 2);
            }
            else{
                setShirtPrice(l * 2);
            }

        }
    }

    @Override
    public double getTotal() {
        Double total = getShirtPrice() * getNumberOfItems();
        return  total;
    }
}
