package com.company.implem;

import com.company.Pants;

public class PanstImplEx extends Pants implements PantsImpl {


    @Override
    public void getPantsPrice(String productTYpe, String size) {
        double s = 10;
        double m = 20;
        double l = 30;
        if (getProductType() == "jeans") {
            if (getPantsSize() == "s") {
                setPantsPrice(s);
            } else if (getPantsSize() == "m") {
                setPantsPrice(m);
            } else {
                setPantsPrice(l);
            }
        }
        if (getProductType()  == "formal pants") {
            if (getPantsSize() == "s") {
                setPantsPrice(s + 30);
            } else if (getPantsSize() == "m") {
                setPantsPrice(m + 30);
            } else {
                setPantsPrice(l + 30);
            }
        }
    }


    @Override
    public double getTotal() {
        Double total = getPantsPrice() * getNumberOfItems();
        return total;
    }
}
