package com.company.implem;

import com.company.Shirt;

public interface ShirtsImpl {
    void getShirtPrice (String productTYpe, String size);
    double getTotal();
}
